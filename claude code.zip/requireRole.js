const { hasRoleAtLeast } = require('../db/users');

/**
 * Usage: bot.command('grant', requireRole('admin'), handler)
 */
function requireRole(minRole) {
  return async (ctx, next) => {
    const ok = await hasRoleAtLeast(ctx.from.id, minRole);
    if (!ok) {
      return ctx.reply(`⛔ This command needs ${minRole}-level access or higher.`);
    }
    return next();
  };
}

module.exports = requireRole;
