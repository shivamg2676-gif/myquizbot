require('dotenv').config();
const { Telegraf } = require('telegraf');
const { getOrCreateUser } = require('./db/users');
const requireRole = require('./middleware/requireRole');
const { startQuiz, handlePollAnswer } = require('./commands/quiz');
const { grantRole } = require('./commands/grant');

const token = process.env.TELEGRAM_BOT_TOKEN;
if (!token) {
  console.error('Missing TELEGRAM_BOT_TOKEN in environment. Set it in Render dashboard.');
  process.exit(1);
}

const bot = new Telegraf(token);

// Ensure every user who interacts is registered in the DB (role defaults to student,
// unless their Telegram id matches OWNER_TELEGRAM_ID).
bot.use(async (ctx, next) => {
  if (ctx.from) {
    try {
      await getOrCreateUser(ctx.from);
    } catch (err) {
      console.error('Failed to upsert user:', err.message);
    }
  }
  return next();
});

bot.start((ctx) =>
  ctx.reply(
    'Welcome to CA Vault Bot 👋\n' +
      'Commands:\n' +
      '/quiz <Subject> — start a quiz (try: /quiz Accounts)\n' +
      '/help — full command list'
  )
);

bot.help((ctx) =>
  ctx.reply(
    '📜 Commands\n\n' +
      '/quiz <Subject> — start a timed quiz\n' +
      '/grant (reply to user) <role> — admin/owner only, sets a user role\n' +
      '\nMore commands (moderation, PDF vault, scheduling, dashboard) ship in later phases.'
  )
);

bot.command('quiz', startQuiz);
bot.command('grant', requireRole('admin'), grantRole);

// Quiz poll answers
bot.on('poll_answer', async (ctx) => {
  await handlePollAnswer(ctx, ctx.pollAnswer);
});

bot.catch((err, ctx) => {
  console.error(`Error for ${ctx.updateType}`, err);
});

// Render web service requirement: bind to $PORT even though this is a bot,
// so Render's health check passes if you deploy as a Web Service.
// If you deploy as a Background Worker instead, you can delete this block.
if (process.env.PORT) {
  const http = require('http');
  http
    .createServer((req, res) => {
      res.writeHead(200);
      res.end('CA Vault Bot is running.');
    })
    .listen(process.env.PORT, () => console.log(`Health server on :${process.env.PORT}`));
}

bot.launch().then(() => console.log('CA Vault Bot launched ✅'));

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
