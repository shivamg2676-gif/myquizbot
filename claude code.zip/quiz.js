const pool = require('../db/pool');
const { applyXp } = require('../db/users');

// Placeholder question bank. Replace with DB-backed / PDF-parsed questions in Phase 2.
const SAMPLE_QUESTIONS = {
  Accounts: [
    {
      q: 'Which accounting concept assumes a business will continue indefinitely?',
      options: ['Going Concern', 'Matching', 'Prudence', 'Materiality'],
      correctIndex: 0,
      type: 'theory', // 25s
    },
    {
      q: 'Depreciation is recorded to match which principle?',
      options: ['Matching', 'Realisation', 'Consistency', 'Dual Aspect'],
      correctIndex: 0,
      type: 'theory',
    },
  ],
  Law: [
    {
      q: 'A contract with a minor is:',
      options: ['Void ab initio', 'Voidable', 'Valid', 'Illegal'],
      correctIndex: 0,
      type: 'theory',
    },
  ],
};

const TIMER_SECONDS = { theory: 25, practical: 45 };

// Tracks active quiz sessions in memory. For multi-instance/Render restarts,
// move this to Redis or a DB table in Phase 2.
const activeSessions = new Map(); // key: chatId:userId -> session state

async function startQuiz(ctx) {
  const subjectArg = (ctx.message.text.split(' ')[1] || 'Accounts').trim();
  const subject = Object.keys(SAMPLE_QUESTIONS).find(
    (s) => s.toLowerCase() === subjectArg.toLowerCase()
  );

  if (!subject) {
    return ctx.reply(
      `Subject not found. Try: /quiz ${Object.keys(SAMPLE_QUESTIONS).join(' | /quiz ')}`
    );
  }

  const questions = SAMPLE_QUESTIONS[subject];
  const key = `${ctx.chat.id}:${ctx.from.id}`;
  activeSessions.set(key, {
    subject,
    questions,
    index: 0,
    correct: 0,
    wrong: 0,
    startedAt: Date.now(),
  });

  await ctx.reply(`📚 Starting ${subject} quiz — ${questions.length} question(s).`);
  await sendNextQuestion(ctx, key);
}

async function sendNextQuestion(ctx, key) {
  const session = activeSessions.get(key);
  if (!session) return;

  if (session.index >= session.questions.length) {
    return finishQuiz(ctx, key);
  }

  const q = session.questions[session.index];
  const timer = TIMER_SECONDS[q.type] || 25;

  await ctx.replyWithPoll(q.q, q.options, {
    type: 'quiz',
    correct_option_id: q.correctIndex,
    is_anonymous: false,
    open_period: timer,
  });
}

// Call this from bot.on('poll_answer', ...) — wired in index.js
async function handlePollAnswer(ctx, pollAnswer) {
  // Telegram poll_answer doesn't carry chat id directly for private polls tracking;
  // for group quizzes keyed per-user we match on the most recent active session for this user.
  const userId = pollAnswer.user.id;
  const matchKey = [...activeSessions.keys()].find((k) => k.endsWith(`:${userId}`));
  if (!matchKey) return;

  const session = activeSessions.get(matchKey);
  const q = session.questions[session.index];
  const isCorrect = pollAnswer.option_ids[0] === q.correctIndex;

  if (isCorrect) session.correct += 1;
  else session.wrong += 1;

  session.index += 1;
  activeSessions.set(matchKey, session);

  if (session.index >= session.questions.length) {
    await finishQuizByKey(ctx, matchKey);
  } else {
    await sendNextQuestion(ctx, matchKey);
  }
}

async function finishQuiz(ctx, key) {
  await finishQuizByKey(ctx, key);
}

async function finishQuizByKey(ctx, key) {
  const session = activeSessions.get(key);
  if (!session) return;
  const [, userId] = key.split(':');
  const timeTaken = Math.round((Date.now() - session.startedAt) / 1000);
  const score = session.correct * 4 - session.wrong * 1;

  await pool.query(
    `INSERT INTO quiz_history (user_id, subject, score, correct_count, wrong_count, time_taken_sec)
     VALUES ($1, $2, $3, $4, $5, $6)`,
    [userId, session.subject, score, session.correct, session.wrong, timeTaken]
  );

  const { xp, level } = await applyXp(userId, session.correct, session.wrong);

  await ctx.reply(
    `✅ Quiz done — ${session.subject}\n` +
      `Correct: ${session.correct} | Wrong: ${session.wrong}\n` +
      `XP: ${xp} | Level: ${level}`
  );

  activeSessions.delete(key);
}

module.exports = { startQuiz, handlePollAnswer };
