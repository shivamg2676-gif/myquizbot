const pool = require('./pool');

const ROLE_RANK = { student: 0, moderator: 1, admin: 2, owner: 3 };

async function getOrCreateUser(telegramUser) {
  const { id, username } = telegramUser;
  const ownerId = Number(process.env.OWNER_TELEGRAM_ID || 0);
  const role = id === ownerId ? 'owner' : 'student';

  const { rows } = await pool.query(
    `INSERT INTO users (user_id, username, role)
     VALUES ($1, $2, $3)
     ON CONFLICT (user_id) DO UPDATE SET username = EXCLUDED.username
     RETURNING *`,
    [id, username || null, role]
  );
  return rows[0];
}

async function hasRoleAtLeast(userId, minRole) {
  const { rows } = await pool.query('SELECT role FROM users WHERE user_id = $1', [userId]);
  if (!rows.length) return false;
  return ROLE_RANK[rows[0].role] >= ROLE_RANK[minRole];
}

// +4 XP correct, -1 XP wrong (per blueprint). Level = 1 + floor(xp / 100), tweak as needed.
async function applyXp(userId, correctCount, wrongCount) {
  const delta = correctCount * 4 - wrongCount * 1;
  const { rows } = await pool.query(
    `UPDATE users
     SET xp = GREATEST(xp + $2, 0),
         level = GREATEST(1 + FLOOR((GREATEST(xp + $2, 0)) / 100.0), 1)
     WHERE user_id = $1
     RETURNING xp, level`,
    [userId, delta]
  );
  return rows[0];
}

async function setRole(userId, role) {
  await pool.query('UPDATE users SET role = $2 WHERE user_id = $1', [userId, role]);
}

module.exports = { getOrCreateUser, hasRoleAtLeast, applyXp, setRole, ROLE_RANK };
