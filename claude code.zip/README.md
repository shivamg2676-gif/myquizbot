# CA Vault Quiz Bot — Phase 1

A Telegram bot foundation for the CA Foundation quiz/vault system. This is the
**first phase** of the full blueprint — a working, deployable core that the
rest of the features (moderation, PDF vault, ICAI sync, scheduling, dashboard)
get built onto.

## ⚠️ First: rotate your API keys

You pasted 5 real API keys earlier in this conversation (Cerebras, Gemini,
Groq, Mistral, OpenRouter). Treat those as burned — regenerate all 5 from
each provider's dashboard before you go live. Only put real values in
Render's **Environment** tab or a local `.env` (which is gitignored) — never
in code, never in a repo, never pasted in chat.

## What's included in Phase 1

- Telegram bot skeleton (Telegraf)
- Postgres schema: users, quiz_history, badges, pdf_index, leaderboard_cache,
  audit_logs, warnings, access_grants (`src/db/schema.sql`)
- Role system: owner / admin / moderator / student, with a `requireRole()`
  middleware to gate commands
- A working `/quiz <Subject>` command using native Telegram quiz polls,
  subject-based timers, XP scoring (+4 correct / -1 wrong), and quiz history
  logged to the DB
- `/grant` command (admin+) to change a user's role by replying to their message
- Render deploy config (`render.yaml`) as a background worker + free Postgres

## What's NOT built yet (later phases)

- Anti-spam word/sticker filters + 3-strike auto-mute
- Force-subscribe / channel membership gatekeeping
- PDF vault with keyword matching, dedup by file hash, admin approval flow
- ICAI website sync/scraper for exam dates, RTP/MTP/PYQ
- 6–8 PM smart scheduling + daily pinned schedule + Sunday cumulative mega quiz
- Leaderboards (daily/weekly/monthly) + badges + streaks
- Interactive `/dashboard` with inline buttons
- DM control center commands (`/settime`, `/addchapter`, `/setmode`, etc.)

Each of these is a self-contained module we can add on top of this
foundation one at a time — that's the sane way to get something this size
actually working instead of broken on day one.

## Setup

1. **Create the bot**: message [@BotFather](https://t.me/BotFather) on
   Telegram, `/newbot`, copy the token.
2. **Get your own Telegram numeric ID**: message
   [@userinfobot](https://t.me/userinfobot) — this becomes `OWNER_TELEGRAM_ID`
   so the bot recognizes you as owner automatically.
3. **Local test (optional)**:
   ```bash
   cp .env.example .env
   # fill in TELEGRAM_BOT_TOKEN, OWNER_TELEGRAM_ID, DATABASE_URL
   npm install
   npm run migrate   # creates all tables
   npm start
   ```

## Deploy to Render

1. Push this folder to a **private** GitHub repo (keep it private — this is
   your bot's source, no reason to make it public).
2. On Render: New → Blueprint → connect the repo → it reads `render.yaml`
   and creates the worker service + free Postgres DB automatically.
3. In the service's Environment tab, set `TELEGRAM_BOT_TOKEN` and
   `OWNER_TELEGRAM_ID` (Render fills `DATABASE_URL` from the linked DB
   automatically if you use the Blueprint).
4. After first deploy, run the migration once — either add
   `npm run migrate && npm start` as a temporary start command for the first
   deploy, or run it from Render's Shell tab.
5. Free-tier background workers on Render can spin down on inactivity — if
   you need guaranteed 24/7, you'll want a paid instance type.

## Adding your group

Add the bot to your Telegram group and **promote it to admin** (it needs
admin rights to eventually mute/restrict users in later phases). Test with
`/quiz Accounts` in the group or in a DM with the bot.

## Next step

Tell me which phase to build next — I'd suggest anti-spam + moderation
(3-strike mute system) or the PDF vault, since those are the two other
systems everything else leans on.
