-- CA Vault Quiz Bot: Core schema (Phase 1)
-- Run once via `npm run migrate`

CREATE TABLE IF NOT EXISTS users (
  user_id        BIGINT PRIMARY KEY,        -- Telegram user id
  username       TEXT,
  role           TEXT NOT NULL DEFAULT 'student'
                   CHECK (role IN ('owner','admin','moderator','student')),
  xp             INTEGER NOT NULL DEFAULT 0,
  level          INTEGER NOT NULL DEFAULT 1,
  streak_count   INTEGER NOT NULL DEFAULT 0,
  last_active_date DATE,
  joined_date    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS quiz_history (
  attempt_id     BIGSERIAL PRIMARY KEY,
  user_id        BIGINT NOT NULL REFERENCES users(user_id),
  subject        TEXT NOT NULL,
  chapter        TEXT,
  score          INTEGER NOT NULL,
  correct_count  INTEGER NOT NULL,
  wrong_count    INTEGER NOT NULL,
  time_taken_sec INTEGER,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS badges (
  badge_id       BIGSERIAL PRIMARY KEY,
  user_id        BIGINT NOT NULL REFERENCES users(user_id),
  badge_name     TEXT NOT NULL,
  earned_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS pdf_index (
  pdf_id             BIGSERIAL PRIMARY KEY,
  file_id            TEXT NOT NULL,          -- Telegram file_id
  file_hash          TEXT NOT NULL,          -- for dedup (sha256 of file content or telegram file_unique_id)
  file_name          TEXT,
  keyword            TEXT,                   -- e.g. #law_ch2
  uploaded_by        BIGINT REFERENCES users(user_id),
  channel_message_id BIGINT,
  approved           BOOLEAN NOT NULL DEFAULT false,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(file_hash)
);

CREATE TABLE IF NOT EXISTS leaderboard_cache (
  user_id        BIGINT NOT NULL REFERENCES users(user_id),
  period         TEXT NOT NULL CHECK (period IN ('daily','weekly','monthly')),
  period_key     TEXT NOT NULL,   -- e.g. '2026-08-09', '2026-W32', '2026-08'
  periodic_score INTEGER NOT NULL DEFAULT 0,
  rank           INTEGER,
  PRIMARY KEY (user_id, period, period_key)
);

CREATE TABLE IF NOT EXISTS audit_logs (
  log_id         BIGSERIAL PRIMARY KEY,
  actor_id       BIGINT,               -- admin/mod id, NULL if bot-automated
  target_user_id BIGINT,
  action_type    TEXT NOT NULL,        -- mute, unmute, warning, referral_change, pdf_upload, role_change
  reason         TEXT,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS warnings (
  warning_id     BIGSERIAL PRIMARY KEY,
  user_id        BIGINT NOT NULL REFERENCES users(user_id),
  reason         TEXT,
  issued_by      BIGINT,               -- NULL if auto-filter
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS access_grants (
  user_id        BIGINT PRIMARY KEY REFERENCES users(user_id),
  plan           TEXT NOT NULL DEFAULT 'trial_1week'
                   CHECK (plan IN ('trial_1week','trial_2week','trial_3week','full_free')),
  granted_by     BIGINT,
  expires_at     TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_quiz_history_user ON quiz_history(user_id);
CREATE INDEX IF NOT EXISTS idx_warnings_user ON warnings(user_id);
CREATE INDEX IF NOT EXISTS idx_pdf_keyword ON pdf_index(keyword);
