const { setRole } = require('../db/users');

async function grantRole(ctx) {
  // Usage: /grant @username admin  (reply-to also supported)
  const parts = ctx.message.text.split(' ').slice(1);
  const role = (parts[1] || '').toLowerCase();
  const validRoles = ['owner', 'admin', 'moderator', 'student'];

  if (!validRoles.includes(role)) {
    return ctx.reply(`Usage: /grant <reply to user> ${validRoles.join('|')}`);
  }
  if (!ctx.message.reply_to_message) {
    return ctx.reply('Reply to the user\'s message with /grant <role>.');
  }

  const targetId = ctx.message.reply_to_message.from.id;
  await setRole(targetId, role);
  await ctx.reply(`✅ Role updated to ${role} for that user.`);
}

module.exports = { grantRole };
